﻿#region using
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

#endregion

// projname: ExStoreTest
// itemname: App
// username: jeffs
// created:  11/27/2022 4:05:08 PM

namespace ExStoreTest
{
	public partial class App : Application
	{


	}
}
